import React from 'react'
import { ProductList } from '../../Components'

const Main = () => {
  return (
    <div className='main-page'>
      <ProductList />
    </div>
  )
}

export default Main
